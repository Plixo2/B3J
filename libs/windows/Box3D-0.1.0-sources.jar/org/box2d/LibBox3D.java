package org.box2d;


import java.io.IOException;
import java.io.InputStream;
import java.lang.foreign.Arena;
import java.lang.foreign.Linker;
import java.lang.foreign.SymbolLookup;
import java.net.URISyntaxException;
import java.net.URL;
import java.nio.channels.FileChannel;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardCopyOption;
import java.util.regex.Pattern;
import java.util.stream.Stream;
import java.util.zip.CRC32;

/// Responsible for loading the native Box3D library
public class LibBox3D {
    private LibBox3D() {}
    
    private static final String VERSION = "0.1.0";

    private static final String CUSTOM_LIBRARY_PATH = System.getProperty("box3d.library.path");
    private static final String CUSTOM_SHIM_LIBRARY_PATH = System.getProperty("box3dshims.library.path");

    private static final String DEFAULT_LIBRARY_PATH = "box3d";
    private static final String DEFAULT_SHIM_LIBRARY_PATH = "box3dshims";

    public static SymbolLookup lookup(Arena arena) {

        var libLookup = lookupLibrary(arena, CUSTOM_LIBRARY_PATH, DEFAULT_LIBRARY_PATH);
        var shimLookup = lookupLibrary(arena, CUSTOM_SHIM_LIBRARY_PATH, DEFAULT_SHIM_LIBRARY_PATH);

        return libLookup
                .or(shimLookup)
                .or(SymbolLookup.loaderLookup())
                .or(Linker.nativeLinker().defaultLookup());

    }

    private static SymbolLookup lookupLibrary(
            Arena arena,
            String property,
            String defaultPath
    ) {

        // 1. Load from custom path, if specified
        if (property != null) {
            var libName = Platform.current.mapLibraryName(property);
            return SymbolLookup.libraryLookup(libName, arena);
        }

        // map to platform-specific library name
        String libName = Platform.current.mapLibraryName(defaultPath);
        

        // 2. try with OS-specific lookup
        try {
            return SymbolLookup.libraryLookup(libName, arena);
        } catch (Exception ignored) {}


        // 3. try bundled resource
        var url = findResource(libName);
        if (url != null) {
            String path = getRegularFilePath(url);

            if (path != null) {
                // regular file, can be loaded directly
                return SymbolLookup.libraryLookup(path, arena);
            } else {
                // extract from resource to temp file and load
                return loadFromResources(url, libName, arena);
            }
        }
        
        // step 2. failed, so just fail with the same error message again
        return SymbolLookup.libraryLookup(libName, arena);
    }




    private static SymbolLookup loadFromResources(URL url, String libName, Arena arena) {
        // find a suitable path to extract the library to
        var file = getExtractPath(libName);
        
        // extract and lock
        try (var ignored = extractLibrary(url, file)){
            return SymbolLookup.libraryLookup(file, arena);
        } catch (IOException e) {
            throw new RuntimeException("Failed to extract native library: " + libName, e);
        }
    }

    private static FileChannel extractLibrary(URL url, Path file) throws IOException {

        if (Files.exists(file)) {
            try (
                    InputStream source = url.openStream();
                    InputStream target = Files.newInputStream(file)
            ) {
                if (crc(source) == crc(target)) {
                    return lock(file);
                }
            }
        }

        Files.createDirectories(file.getParent());
        try (InputStream source = url.openStream()) {
            Files.copy(source, file, StandardCopyOption.REPLACE_EXISTING);
        }
        return lock(file);
    }

    private static FileChannel lock(Path file) {
        // Wait for other processes (usually antivirus software) to unlock the extracted file
        // before attempting to load it.
        try {
            FileChannel fc = FileChannel.open(file);

            if (fc.tryLock(0L, Long.MAX_VALUE, true) == null) {
                fc.lock(0L, Long.MAX_VALUE, true); // this will block until the file is locked
            }
            // the lock will be released when the channel is closed
            return fc;
        } catch (Exception e) {
            throw new RuntimeException("Failed to lock file.", e);
        }
    }

    private static URL findResource(String resource) {
        String bundledResource = Platform.mapLibraryPathBundled(resource);
        return LibBox3D.class.getClassLoader().getResource(bundledResource);
    }

    private static String getRegularFilePath(URL url) {
        if (url.getProtocol().equals("file")) {
            try {
                Path path = Paths.get(url.toURI());
                if (path.isAbsolute() && Files.isReadable(path)) {
                    return path.toString();
                }
            } catch (URISyntaxException ignored) {
            }
        }
        return null;
    }

    private static Path getExtractPath(String filename) {
        String arch = Architecture.current.name().toLowerCase();

        // 1. try system temp directory
        var root = Paths.get(System.getProperty("java.io.tmpdir"));
        var file = root.resolve(Paths.get("box3d" + System.getProperty("user.name").trim(), VERSION, arch, filename));
        if (canWrite(root, file)) {
            return file;
        }

        var nameArchVersion = Paths.get("." + "box3d", VERSION, arch, filename);

        // 2. try user home directory
        root = Paths.get(System.getProperty("user.home"));
        file = root.resolve(nameArchVersion);
        if (canWrite(root, file)) {
            return file;
        }

        // 3. try current working directory
        root = Paths.get("").toAbsolutePath();
        file = root.resolve(nameArchVersion);
        if (canWrite(root, file)) {
            return file;
        }

        throw new RuntimeException("Failed to find an appropriate directory to extract the native library");
    }

    /// test if we can write to the given file
    private static boolean canWrite(Path root, Path file) {
        Path testFile;
        if (Files.exists(file)) {
            if (!Files.isWritable(file)) {
                return false;
            }
            testFile = file.getParent().resolve(".test");
        } else {
            try {
                Files.createDirectories(file.getParent());
            } catch (IOException ignored) {
                return false;
            }
            testFile = file;
        }

        try {
            Files.write(testFile, new byte[0]);
            Files.delete(testFile);
            return true;
        } catch (Throwable ignored) {
            if (file == testFile) {
                canWriteCleanup(root, file);
            }
            return false;
        }
    }


    private static void canWriteCleanup(Path root, Path file) {
        try {
            Files.deleteIfExists(file);
            Path parent = file.getParent();
            while (!Files.isSameFile(parent, root)) {
                try (Stream<Path> dir = Files.list(parent)) {
                    if (dir.findAny().isPresent()) {
                        break;
                    }
                }
                Files.delete(parent);
                parent = parent.getParent();
            }
        } catch (IOException ignored) {
        }
    }

    private static long crc(InputStream input) throws IOException {
        CRC32 crc = new CRC32();

        byte[] buffer = new byte[8 * 1024];
        for (int n; (n = input.read(buffer)) != -1; ) {
            crc.update(buffer, 0, n);
        }

        return crc.getValue();
    }

    
    public enum Architecture {
        X64(true),
        X86(false),
        ARM64(true),
        ARM32(false),
        PPC64LE(true),
        RISCV64(true);

        static final Architecture current;

        final boolean is64Bit;

        static {
            String  osArch  = System.getProperty("os.arch");
            boolean is64Bit = osArch.contains("64") || osArch.startsWith("armv8");

            if (osArch.startsWith("arm") || osArch.startsWith("aarch")) {
                current = is64Bit ? Architecture.ARM64 : Architecture.ARM32;
            } else if (osArch.startsWith("ppc")) {
                if (!"ppc64le".equals(osArch)) {
                    throw new UnsupportedOperationException("Only PowerPC 64 LE is supported.");
                }
                current = Architecture.PPC64LE;
            } else if (osArch.startsWith("riscv")) {
                if (!"riscv64".equals(osArch)) {
                    throw new UnsupportedOperationException("Only RISC-V 64 is supported.");
                }
                current = Architecture.RISCV64;
            } else {
                current = is64Bit ? Architecture.X64 : Architecture.X86;
            }
        }

        Architecture(boolean is64Bit) {
            this.is64Bit = is64Bit;
        }

    }


    private enum Platform {
        FREEBSD("freebsd") {
            private final Pattern SO = Pattern.compile("(?:^|/)lib\\w+[.]so(?:[.]\\d+)*$");

            @Override
            String mapLibraryName(String name) {
                if (SO.matcher(name).find()) {
                    return name;
                }

                return System.mapLibraryName(name);
            }
        },
        LINUX("linux") {
            private final Pattern SO = Pattern.compile("(?:^|/)lib\\w+[.]so(?:[.]\\d+)*$");

            @Override
            String mapLibraryName(String name) {
                if (SO.matcher(name).find()) {
                    return name;
                }

                return System.mapLibraryName(name);
            }
        },
        MACOSX("macos") {
            private final Pattern DYLIB = Pattern.compile("(?:^|/)lib\\w+(?:[.]\\d+)*[.]dylib$");

            @Override
            String mapLibraryName(String name) {
                if (DYLIB.matcher(name).find()) {
                    return name;
                }

                return System.mapLibraryName(name);
            }
        },
        WINDOWS("windows") {
            @Override
            String mapLibraryName(String name) {
                if (name.endsWith(".dll")) {
                    return name;
                }

                return System.mapLibraryName(name);
            }
        };
        private static final Platform current;

        static {
            String osName = System.getProperty("os.name");
            if (osName.startsWith("Windows")) {
                current = WINDOWS;
            } else if (osName.startsWith("FreeBSD")) {
                current = FREEBSD;
            } else if (osName.startsWith("Linux") || osName.startsWith("SunOS") || osName.startsWith("Unix")) {
                current = LINUX;
            } else if (osName.startsWith("Mac OS X") || osName.startsWith("Darwin")) {
                current = MACOSX;
            } else {
                throw new LinkageError("Unknown platform: " + osName);
            }
        }

        private final String nativePath;

        Platform(String nativePath) {
            this.nativePath = nativePath;
        }

        abstract String mapLibraryName(String name);


        private static String mapLibraryPathBundled(String name) {
            return "natives/box3d/" + current.nativePath + "/" + Architecture.current.name().toLowerCase() + "/" + name;
        }

    }
}
